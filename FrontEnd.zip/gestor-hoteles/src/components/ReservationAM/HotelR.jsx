export const HotelR = ({ name, direction}) => {
    return (
        <>
            <td>{name}</td>
            <td>{direction}</td>                                                    
        </>
    )
}