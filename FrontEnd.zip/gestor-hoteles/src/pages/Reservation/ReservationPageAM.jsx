import React from 'react'
import TableReservationAM from '../../components/ReservationAM/TableReservationAM'

const ReservationPageAM = () => {
  return (
    <TableReservationAM></TableReservationAM>
  )
}

export default ReservationPageAM
