import React from 'react'
import { TableReservation } from '../../components/Reservation/TableReservation'

const ReservatonPage = () => {
  return (
    <TableReservation></TableReservation>
  )
}

export default ReservatonPage
