import React from 'react'
import SimpleBarCharts from '../components/SimpleBarCharts/SimpleBarCharts'

const GraphicsPage = () => {
  return (
    <SimpleBarCharts></SimpleBarCharts>
  )
}

export default GraphicsPage
